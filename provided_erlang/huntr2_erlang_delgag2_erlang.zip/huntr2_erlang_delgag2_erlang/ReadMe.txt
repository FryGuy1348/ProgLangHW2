Names: Ryan Hunt (huntr2) & Anthony Delgado (delgag2)
Date to be submitted: 10/31/2021
Homework #2: Distributed File Sharing

Bugs/Issues - None at the moment. There are delays/timer:sleep calls in the get function to give the process time to gather files, so it may take a second or two for the files to appear in the downloads folder.
Has had issues running with run.sh (Mostly due to ubuntu + system, not due to main.erl itself)